package com.reportoverlay

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Админ-клавиатура. Вкладки: Начало / Конец (быстрые ответы), Команды, Наказания, FamWar,
 * ABC (буквы), ID (номер игрока). Окно репорта вставляет текст через неё.
 */
class AdminKeyboard : InputMethodService() {

    companion object {
        @Volatile var instance: AdminKeyboard? = null

        /** ID игрока, с которым работаем (ставится из окна репорта или вводится вручную). */
        @Volatile var targetId: String = ""

        /** Вставить текст в открытое поле чата. false — поле ввода сейчас не открыто. */
        fun insert(text: String): Boolean {
            val k = instance ?: return false
            return k.insertText(text)
        }

        fun setId(id: String) {
            targetId = id
            instance?.refreshBar()
        }

        private val BG = Color.parseColor("#2A1A12")
        private val KEY = Color.parseColor("#4A2F1E")
        private val ACCENT = Color.parseColor("#E0822F")
        private val TXT = Color.parseColor("#FFE9D2")
        private val MUTED = Color.parseColor("#C9A98C")
    }

    private val tabs = listOf("Начало", "Конец", "Команды", "Наказания", "FamWar", "ABC", "ID")
    private var tab = 5

    private var body: LinearLayout? = null
    private var idChip: TextView? = null
    private var sendBtn: TextView? = null
    private val tabViews = ArrayList<TextView>()
    private val letterViews = ArrayList<TextView>()
    private var shift = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        // Верхняя полоса: вкладки и кнопки «Стереть» / «Отправить»
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabViews.clear()
        for ((i, name) in tabs.withIndex()) {
            val t = key(name, 12f) { selectTab(i) }
            if (name == "ID") idChip = t
            tabViews.add(t)
            bar.addView(t, barLp(dp(62)))
        }
        bar.addView(key("Стереть", 12f) { clearAll() }, barLp(dp(70)))
        val send = key("Отправить", 12f) { sendMessage() }
        send.setOnLongClickListener {
            prefs().edit().putInt("pmCount", 0).apply()
            refreshBar()
            Toast.makeText(this, "Счётчик сброшен", Toast.LENGTH_SHORT).show()
            true
        }
        sendBtn = send
        bar.addView(send, barLp(dp(92)))

        val scrollBar = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(bar)
        }
        root.addView(
            scrollBar,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(36))
        )

        val b = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body = b
        root.addView(
            b,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(132))
        )

        selectTab(tab)
        return root
    }

    // В ландшафте система по умолчанию растягивает клавиатуру на весь экран — отключаем
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        refreshBar()
    }

    // ---------- элементы ----------

    private fun rounded(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(8).toFloat()
    }

    private fun key(label: String, size: Float, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(TXT)
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(KEY)
        maxLines = 3
        setPadding(dp(4), dp(2), dp(4), dp(2))
        setOnClickListener {
            buzz()
            onClick()
        }
    }

    private fun barLp(w: Int) = LinearLayout.LayoutParams(w, LinearLayout.LayoutParams.MATCH_PARENT).apply {
        setMargins(dp(2), dp(2), dp(2), dp(2))
    }

    private fun rowLp(weight: Float = 1f) =
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }

    private fun buzz() {
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Throwable) {
        }
    }

    private fun prefs() = getSharedPreferences("cfg", MODE_PRIVATE)

    // ---------- состояние полосы ----------

    fun refreshBar() {
        idChip?.text = if (targetId.isBlank()) "ID" else "ID $targetId"
        sendBtn?.text = "Отправить ·${prefs().getInt("pmCount", 0)}"
        for ((i, t) in tabViews.withIndex()) {
            t.background = rounded(if (i == tab) ACCENT else KEY)
            t.setTextColor(if (i == tab) Color.parseColor("#2A1A12") else TXT)
        }
    }

    private fun selectTab(i: Int) {
        tab = i
        refreshBar()
        val b = body ?: return
        b.removeAllViews()
        letterViews.clear()
        when (tabs[i]) {
            "Начало" -> b.addView(grid(Phrases.QUICK_START.map { it to "/pm %ID% $it" }, 2))
            "Конец" -> b.addView(grid(Phrases.QUICK_END.map { it to "/pm %ID% $it" }, 2))
            "Команды" -> b.addView(grid(Phrases.COMMANDS.map { it.replace("%ID%", "ID") to it }, 4))
            "Наказания" -> b.addView(grid(Phrases.PUNISHMENTS.map { it.label to it.command }, 3))
            "FamWar" -> b.addView(grid(Phrases.FAMWAR.map { it.label to it.command }, 3))
            "ABC" -> buildLetters(b)
            "ID" -> buildIdPad(b)
        }
    }

    /** Список кнопок: подпись → шаблон команды (ID подставляется при нажатии). */
    private fun grid(items: List<Pair<String, String>>, columns: Int): View {
        val g = GridLayout(this).apply { columnCount = columns }
        for ((label, template) in items) {
            val k = key(label, 11f) { insertText(Phrases.fill(template, targetId)) }
            k.minHeight = dp(40)
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            ).apply {
                width = 0
                height = GridLayout.LayoutParams.WRAP_CONTENT
                setMargins(dp(2), dp(2), dp(2), dp(2))
            }
            g.addView(k, lp)
        }
        return ScrollView(this).apply { addView(g) }
    }

    // ---------- буквы ----------

    private fun buildLetters(b: LinearLayout) {
        fun row(chars: String, extraStart: View? = null, extraEnd: View? = null) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            if (extraStart != null) r.addView(extraStart, rowLp(1.4f))
            for (ch in chars) r.addView(letter(ch.toString()), rowLp())
            if (extraEnd != null) r.addView(extraEnd, rowLp(1.4f))
            b.addView(r, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        row("1234567890")
        row("йцукенгшщзхъ")
        row("фывапролджэ")
        row("ячсмитьбюё", extraStart = key("⇧", 14f) { toggleShift() }, extraEnd = key("⌫", 14f) { backspace() })

        val last = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (s in listOf("/", ".", ",", "!", "?", "-")) last.addView(letter(s, plain = true), rowLp())
        last.addView(key("пробел", 12f) { insertText(" ") }, rowLp(3f))
        b.addView(last, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    private fun letter(ch: String, plain: Boolean = false): TextView {
        val t = key(ch, 15f) {}
        t.setOnClickListener {
            buzz()
            val out = if (!plain && shift) ch.uppercase() else ch
            insertText(out)
            if (shift) {
                shift = false
                updateLetters()
            }
        }
        if (!plain && ch[0].isLetter()) letterViews.add(t)
        return t
    }

    private fun toggleShift() {
        shift = !shift
        updateLetters()
    }

    private fun updateLetters() {
        for (t in letterViews) {
            val base = t.text.toString().lowercase()
            t.text = if (shift) base.uppercase() else base
        }
    }

    // ---------- ID ----------

    private fun buildIdPad(b: LinearLayout) {
        val info = TextView(this).apply {
            text = if (targetId.isBlank()) "Введите ID игрока" else "ID игрока: $targetId"
            setTextColor(MUTED)
            textSize = 13f
            gravity = Gravity.CENTER
        }
        b.addView(info, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        fun refreshInfo() {
            info.text = if (targetId.isBlank()) "Введите ID игрока" else "ID игрока: $targetId"
            refreshBar()
        }

        val digits = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (d in "1234567890") {
            digits.addView(key(d.toString(), 16f) {
                if (targetId.length < 5) setId(targetId + d)
                refreshInfo()
            }, rowLp())
        }
        b.addView(digits, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.2f))

        val ctrl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ctrl.addView(key("⌫", 16f) {
            setId(targetId.dropLast(1))
            refreshInfo()
        }, rowLp())
        ctrl.addView(key("Очистить ID", 13f) {
            setId("")
            refreshInfo()
        }, rowLp(2f))
        b.addView(ctrl, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.2f))
    }

    // ---------- ввод ----------

    fun insertText(text: String): Boolean {
        val ic = currentInputConnection ?: return false
        ic.commitText(text, 1)
        return true
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
    }

    private fun clearAll() {
        val ic = currentInputConnection ?: return
        ic.deleteSurroundingText(100000, 100000)
    }

    private fun sendMessage() {
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(1000, 0)?.toString().orEmpty()
        val after = ic.getTextAfterCursor(1000, 0)?.toString().orEmpty()
        if ((before + after).trimStart().startsWith("/pm", ignoreCase = true)) {
            prefs().edit().putInt("pmCount", prefs().getInt("pmCount", 0) + 1).apply()
            refreshBar()
        }
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnterAction = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }
}
