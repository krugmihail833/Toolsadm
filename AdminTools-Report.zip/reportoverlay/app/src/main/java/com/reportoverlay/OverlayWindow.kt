package com.reportoverlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Окно «Жалоба/Вопрос от игрока» поверх игры. */
class OverlayWindow private constructor(private val app: Context) {

    companion object {
        @Volatile
        private var inst: OverlayWindow? = null

        fun get(c: Context): OverlayWindow =
            inst ?: synchronized(this) {
                inst ?: OverlayWindow(c.applicationContext).also { inst = it }
            }

        private val PURPLE = Color.parseColor("#B06FE0")
        private val PURPLE_DARK = Color.parseColor("#8E4FC4")
        private val PANEL = Color.parseColor("#F2201A2E")
        private val FIELD = Color.parseColor("#33FFFFFF")
    }

    private val main = Handler(Looper.getMainLooper())
    private val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val imm = app.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    private val density = app.resources.displayMetrics.density

    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var content: LinearLayout? = null
    private var info: TextView? = null
    private var input: EditText? = null
    private var current: Report? = null

    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0

    private fun dp(v: Int) = (v * density).toInt()

    // ---------- публичные методы ----------

    fun show(r: Report) {
        main.post {
            current = r
            AdminKeyboard.setId(r.id)
            if (root == null) build()
            info?.text = "${r.nick}[${r.id}]\n${r.text}"
            input?.setText("")
            showMain()
            val v = root ?: return@post
            if (v.parent == null) wm.addView(v, params)
        }
    }

    fun hide() {
        main.post {
            setFocusable(false)
            root?.let { if (it.parent != null) wm.removeView(it) }
        }
    }

    // ---------- построение окна ----------

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun build() {
        val dm = app.resources.displayMetrics
        val screenW = maxOf(dm.widthPixels, dm.heightPixels)
        val width = dp(340)

        val p = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = maxOf(0, screenW - width - dp(16))
        p.y = dp(24)
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        params = p

        val panel = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(PANEL, 14)
        }

        // Шапка (за неё окно можно перетаскивать)
        val header = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(PURPLE)
                val r = dp(14).toFloat()
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
        }
        val title = TextView(app).apply {
            text = "Жалоба/Вопрос от игрока"
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            textSize = 14f
        }
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val close = TextView(app).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(2), dp(12), dp(2))
            setOnClickListener { hide() }
        }
        header.addView(close)
        header.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = p.x; startY = p.y
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (e.rawX - downX).toInt()
                    p.y = startY + (e.rawY - downY).toInt()
                    root?.let { if (it.parent != null) wm.updateViewLayout(it, p) }
                }
            }
            true
        }
        panel.addView(header)

        // Данные репорта
        val infoView = TextView(app).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            maxLines = 6
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(12), dp(8), dp(12), dp(4))
        }
        info = infoView
        panel.addView(infoView)

        // Поле ответа
        val et = EditText(app).apply {
            hint = "Введите свой ответ"
            setHintTextColor(Color.parseColor("#99FFFFFF"))
            setTextColor(Color.WHITE)
            textSize = 13f
            background = rounded(FIELD, 8)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            maxLines = 3
        }
        et.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                setFocusable(true)
                v.requestFocus()
                main.postDelayed({ imm.showSoftInput(v, 0) }, 150)
            }
            false
        }
        input = et
        val etLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(dp(10), dp(4), dp(10), dp(4)) }
        panel.addView(et, etLp)

        // Кнопки
        val body = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(2), dp(6), dp(8))
        }
        content = body
        panel.addView(body)

        root = panel
    }

    private fun setFocusable(on: Boolean) {
        val p = params ?: return
        val v = root ?: return
        p.flags = if (on) {
            p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        if (v.parent != null) {
            wm.updateViewLayout(v, p)
            if (!on) imm.hideSoftInputFromWindow(v.windowToken, 0)
        }
    }

    // ---------- элементы ----------

    private fun btn(label: String, onClick: () -> Unit): TextView = TextView(app).apply {
        text = label
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        textSize = 13f
        gravity = Gravity.CENTER
        minHeight = dp(40)
        maxLines = 4
        setPadding(dp(8), dp(6), dp(8), dp(6))
        background = rounded(PURPLE_DARK, 10)
        setOnClickListener { onClick() }
    }

    private fun lp(weight: Float = 1f) =
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight).apply {
            setMargins(dp(4), dp(4), dp(4), dp(4))
        }

    private fun row(vararg views: View): LinearLayout {
        val r = LinearLayout(app).apply { orientation = LinearLayout.HORIZONTAL }
        for (v in views) r.addView(v, lp())
        return r
    }

    private fun fullBtn(label: String, onClick: () -> Unit): TextView = btn(label, onClick)

    private fun fullLp() =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }

    private fun scrolled(inner: View): ScrollView = ScrollView(app).apply {
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(220)
        )
        addView(inner)
    }

    // ---------- экраны ----------

    private fun showMain() {
        val c = content ?: return
        c.removeAllViews()
        c.addView(row(btn("Ответить") { reply() }, btn("Уточните") { send("/pm %ID% ${Phrases.CLARIFY}") }))
        c.addView(row(btn("Быстрые ответы") { showQuick() }, btn("Оффтоп") { showOfftop() }))
        c.addView(fullBtn("Другие наказания") { showPunish() }, fullLp())
    }

    private fun showOfftop() {
        val c = content ?: return
        c.removeAllViews()
        c.addView(
            row(
                btn("Предупредить") { send("/pm %ID% ${Phrases.OFFTOP_WARN}") },
                btn("Наказать") { send(Phrases.OFFTOP_PUNISH) }
            )
        )
        c.addView(fullBtn("‹ Назад") { showMain() }, fullLp())
    }

    private fun showQuick() {
        val c = content ?: return
        c.removeAllViews()

        fun column(title: String, items: List<String>): LinearLayout {
            val col = LinearLayout(app).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(app).apply {
                text = title
                setTextColor(Color.parseColor("#D9B8F5"))
                setTypeface(typeface, Typeface.BOLD)
                textSize = 12f
                gravity = Gravity.CENTER
            }, fullLp())
            for (t in items) {
                col.addView(btn(t) { send("/pm %ID% $t") }, fullLp())
            }
            return col
        }

        val both = LinearLayout(app).apply { orientation = LinearLayout.HORIZONTAL }
        both.addView(column("Начало", Phrases.QUICK_START), lp())
        both.addView(column("Результат", Phrases.QUICK_END), lp())
        c.addView(scrolled(both))
        c.addView(fullBtn("‹ Назад") { showMain() }, fullLp())
    }

    private fun showPunish() {
        val c = content ?: return
        c.removeAllViews()
        val list = LinearLayout(app).apply { orientation = LinearLayout.VERTICAL }
        for (p in Phrases.PUNISHMENTS + Phrases.FAMWAR) {
            list.addView(btn(p.label) { send(p.command) }, fullLp())
        }
        c.addView(scrolled(list))
        c.addView(fullBtn("‹ Назад") { showMain() }, fullLp())
    }

    // ---------- действия ----------

    private fun reply() {
        val t = input?.text?.toString()?.trim().orEmpty()
        if (t.isEmpty()) {
            Toast.makeText(app, "Введите ответ", Toast.LENGTH_SHORT).show()
            return
        }
        input?.setText("")
        // Сначала возвращаем фокус игре, иначе клавиатура останется привязана к полю окна
        setFocusable(false)
        main.postDelayed({ send("/pm %ID% $t") }, 450)
    }

    private fun send(template: String) {
        val r = current ?: return
        Inserter.deliver(app, Phrases.fill(template, r.id))
    }
}
