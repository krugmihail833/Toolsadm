package com.reportoverlay

/** Готовая кнопка наказания: подпись и команда (ID — как %ID%). */
class Punish(val label: String, val command: String)

/**
 * Разбор таблицы наказаний в кнопки.
 * Строка основной таблицы:  код|пояснение|команда   (например  2.1 ОП|оск. игрока|mute 15-30)
 *   - диапазон «15-30» даёт две кнопки (15 и 30);
 *   - «mute 30-60 / ban 3-31» и «jail 90+warn» дают отдельные кнопки на каждую команду.
 * Строка FamWar:  код|пояснение|команда|срок  (срок 0 — без срока)
 * Причина в команде — код нарушения (как в ваших примерах: /jail 234 30 DM).
 */
object Punishments {

    private val TEMPLATES = mapOf(
        "ban" to "/ban %ID% %T% %R%",
        "jail" to "/jail %ID% %T% %R%",
        "mute" to "/mute %ID% %T% %R%",
        "rmute" to "/rmute %ID% %T% %R%",
        "warn" to "/warn %ID% %R%",
        "kick" to "/kick %ID% %R%",
        "spawn" to "/spawn %ID%"
    )

    private fun build(name: String, time: String?, reason: String): String {
        val tpl = TEMPLATES[name] ?: "/$name %ID% %T% %R%"
        return tpl
            .replace("%T% ", if (time != null) "$time " else "")
            .replace("%T%", time ?: "")
            .replace("%R%", reason)
            .trim()
    }

    private fun timesOf(token: String?): List<String?> {
        if (token == null) return listOf(null)
        val m = Regex("^(\\d+)(?:-(\\d+))?$").find(token) ?: return listOf(null)
        val a = m.groupValues[1]
        val b = m.groupValues[2]
        return if (b.isEmpty()) listOf(a) else listOf(a, b)
    }

    fun parseMain(table: String): List<Punish> {
        val out = ArrayList<Punish>()
        for (line in table.lines()) {
            val f = line.split("|")
            if (f.size < 3) continue
            val code = f[0].trim()
            val note = f[1].trim()
            if (code.isEmpty()) continue
            for (part in f[2].split("/", "+")) {
                val tokens = part.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
                if (tokens.isEmpty()) continue
                val name = tokens[0].lowercase()
                for (t in timesOf(tokens.getOrNull(1))) {
                    val tail = if (t != null) "$name $t" else name
                    val label = buildString {
                        append(code).append(" · ").append(tail)
                        if (note.isNotEmpty()) append("\n").append(note)
                    }
                    out.add(Punish(label, build(name, t, code)))
                }
            }
        }
        return out
    }

    fun parseFamWar(table: String): List<Punish> {
        val out = ArrayList<Punish>()
        for (line in table.lines()) {
            val f = line.split("|")
            if (f.size < 3) continue
            val code = f[0].trim()
            val note = f[1].trim()
            val name = f[2].trim().lowercase()
            val time = f.getOrNull(3)?.trim()?.takeIf { it.isNotEmpty() && it != "0" }
            if (code.isEmpty() || name.isEmpty()) continue
            val tail = if (time != null) "$name $time" else name
            out.add(Punish("FW $code · $tail\n$note", build(name, time, "FW $code")))
        }
        return out
    }
}
