package com.reportoverlay

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val REQ_PROJECTION = 11
    private val REQ_NOTIF = 12

    private lateinit var status: TextView
    private val fields = LinkedHashMap<String, EditText>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
            setBackgroundColor(Color.parseColor("#1E1830"))
        }

        fun label(t: String, size: Float = 14f, color: Int = Color.WHITE) = TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            setPadding(0, dp(6), 0, dp(2))
        }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#8E4FC4"))
                cornerRadius = dp(10).toFloat()
            }
            setOnClickListener { onClick() }
        }

        fun btnLp() = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, dp(6), 0, dp(2)) }

        col.addView(label("Репорты — оверлей", 20f))
        status = label("Статус: ${Debug.status}", 13f, Color.parseColor("#D9B8F5"))
        col.addView(status)

        col.addView(button("1. Разрешить окна поверх приложений") {
            if (Settings.canDrawOverlays(this)) {
                toast("Уже разрешено")
            } else {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }, btnLp())

        col.addView(button("2. Включить клавиатуру «Админ-клавиатура»") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, btnLp())
        col.addView(button("3. Выбрать её как текущую") {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .showInputMethodPicker()
        }, btnLp())

        col.addView(label("Область чата на экране, % от экрана (в ландшафте)", 13f))
        fun field(key: String, hint: String, def: Int) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(label(hint, 13f).apply { minWidth = dp(150) })
            val et = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(prefs.getInt(key, def).toString())
                setTextColor(Color.WHITE)
                textSize = 14f
            }
            fields[key] = et
            row.addView(et, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            col.addView(row)
        }
        field("left", "Слева", 22)
        field("top", "Сверху", 0)
        field("right", "Справа", 68)
        field("bottom", "Снизу", 30)
        field("interval", "Пауза, мс", 1500)

        col.addView(button("4. Запустить слежение") { startCapture() }, btnLp())
        col.addView(button("Остановить") {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
            refresh()
        }, btnLp())
        col.addView(button("Показать тестовое окно") {
            if (!Settings.canDrawOverlays(this)) {
                toast("Сначала разрешите окна поверх приложений")
            } else {
                OverlayWindow.get(this).show(Report("Test_Player", "123", "Следить за Ivan_Petrov[45]"))
            }
        }, btnLp())
        col.addView(button("Что распознано") { refresh(true) }, btnLp())

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh(withText: Boolean = false) {
        var s = "Статус: ${Debug.status}\nСканирований: ${Debug.scans}"
        if (withText) s += "\n\n--- распознанный текст ---\n" + Debug.lastText
        status.text = s
    }

    private fun savePrefs() {
        val e = getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
        for ((k, v) in fields) {
            val n = v.text.toString().trim().toIntOrNull() ?: continue
            e.putInt(k, if (k == "interval") n.coerceAtLeast(500) else n)
        }
        e.apply()
    }

    private fun startCapture() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Сначала разрешите окна поверх приложений")
            return
        }
        savePrefs()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_NOTIF) startCapture()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PROJECTION) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                startForegroundService(i)
                toast("Запущено. Откройте игру.")
            } else {
                toast("Без разрешения на запись экрана не заработает")
            }
            refresh()
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
