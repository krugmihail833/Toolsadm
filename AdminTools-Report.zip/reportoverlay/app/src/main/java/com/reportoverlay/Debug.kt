package com.reportoverlay

/** Что видит приложение — показывается кнопкой «Что распознано» на главном экране. */
object Debug {
    @Volatile var status: String = "не запущено"
    @Volatile var lastText: String = ""
    @Volatile var scans: Int = 0
}
