package com.reportoverlay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast

/**
 * Передача текста в игру: сначала через админ-клавиатуру прямо в открытое поле чата.
 * Если поле чата не открыто (или выбрана другая клавиатура) — текст копируется в буфер обмена.
 */
object Inserter {

    fun deliver(ctx: Context, text: String): Boolean {
        if (AdminKeyboard.insert(text)) {
            Toast.makeText(ctx, "Вставлено", Toast.LENGTH_SHORT).show()
            return true
        }
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("cmd", text))
        Toast.makeText(
            ctx,
            "Чат не открыт — скопировано. Откройте чат и вставьте: $text",
            Toast.LENGTH_LONG
        ).show()
        return false
    }
}
